KONECT RELEASE FIXTURE
artifact konect.mjs
version 0.6.9
Test data for the release verifier contract (#1702). Not a program.
KONECT RELEASE FIXTURE
artifact konect.mjs
version 0.6.9
Test data for the release verifier contract (#1702). Not a program.
KONECT RELEASE FIXTURE
artifact konect.mjs
version 0.6.9
Test data for the release verifier contract (#1702). Not a program.
